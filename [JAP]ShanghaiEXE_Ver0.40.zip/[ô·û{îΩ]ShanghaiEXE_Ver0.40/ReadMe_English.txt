Genso Network Shanghai.exe �� Trial Ver0.40
Creator: �R�[�L�[

�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q

�yINTRODUCTION�z
This program is a trial version.

You can create screenshots, videos, fanart (18+ is fine), etc. of this trial version.
In fact, making them will help speed up the game's production.



New Content

�EUp to the end of Chapter 4 (Can't sleep in bed)

�EBoth V2 and V3 of the first and fourth bosses can be fought if the appropriate conditions are met, which you should naturally know if you remember the original version.

�EAfter Chapter 4 is cleared, a warp to an extra room will appear in Shanghai's private room.



�yWARNING�z

����������������������������������������������
����
�����@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@����
����
�@ THIS PROGRAM ONLY RUNS �@�@�@����
�@     
�����@�@ON WINDOWS XP OR LATER �@  ����
�����@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@����
����
����������������������������������������������



�yBEFORE STARTING�z

The following runtimes are required to start the program.

Please install them if you don't have them:

SlimDX�@January 2012�@End-User Runtime (English)
https://slimdx.org/download.php

Microsoft .NET Framework 4 
http://www.microsoft.com/downloads/ja-jp/details.aspx?familyid=9cfb2d51-5ff4-4491-b0e5-b386f32c0992&displaylang=ja-nec

DirectX End-User Runtime
http://www.microsoft.com/downloads/ja-jp/details.aspx?FamilyID=2da43d38-db71-4c1b-bc6a-9b6652cd92a3

Upon startup, graphics board is not supported.


If you recieve this message, the game will not start.
Please obtain a DirectX-compatible graphics board.



"Upon startup, graphics board is not supported."
If you recieve this message, the game will not start.
Please obtain a DirectX-compatible graphics board.

If the game does not start up after installing the Runtimes,

It might start up after the PC is rebooted.



�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q

�yCONTROLS�z

(Button names are the same as in the KeyConfig)


D-Pad: Move cursor, Move character


A Button: Make decisions, Talk, Inspect, Use chips

B Button: Cancel, Run, Buster (hold to charge)



START Button: Start game, Pause, Open menu

SELECT Button: Skip events, Set regular chip



R Button: Open custom screen, Show chip explanation

L Button: Open custom screen, Listen to hints, Escape from encounter



�� You can reset the game by pressing L, R, START, SELECT at the same time

�� You can reset the game by pressing A, B, START, SELECT at the same time

�� You can exit the game by pressing the ESC key on the title screen



�yIF A BUG IS FOUND�z

If you find a bug or other problem while playing, report it by replying to

the latest thread on the Shanghai.EXE Development Support Board

http://shanghaiexe.webspace.ne.jp/bbs/

Please help improve the quality of the game!

(Note: the board is in Japanese.)

�ySAVE DATA�z

Save data is compatible between different versions.

You can transfer save data between versions by moving the 

"save.she" file

 in the "

gamedata"

 folder



�yMUSIC PLAYER�z

You can play game's BGM the same way it's played in-game

Please note: It was reasonably made, so it's not guaranteed to work properly



Because unused tracks planned for later chapters are included, beware of spoilers.

Please refrain from using unused tracks in outside material, such as BGM videos



�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q

�yDEVELOPMENT TEAM�z

�EProducer, Programmer, Scenario Designer, Map Graphic Designer, Virus Designer, Chip Designer, etc.

�R�[�L�[



�EChief Graphics Designer, Character Designer, Navi Chip Designer

�Ȃ߂��L



�EGraphics Assistant

�ӂ��@�ԑ�t�@�t�i�~�E�f�B���S�@REDmiso



�EGraphics Guest Collaborator
����l



�EChief Sound Designer, BGM, SFX

�ԃk�D



�EBGM

���l



�EProgram Support

hebo-MAI



�EDebug Players

���ɂ܂�@�u���[�@�����V�m�@���ފ݁@Rin�@�t���E�X�K���@�݂�����


�ELocalization Team
Manager:
  doicm
Translators:
  Kerreb17
  Code Caster
Editors:
  fatkid
  Cloudmonkey98
Quality Control:
  GrayKitsune
  KyrieZee


�yOTHER CONTENT SOURCES�z

PANICPUMPKIN

http://pansound.com/panicpumpkin/



�U�E�}�b�`���C�J�@�Y2nd

http://osabisi.sakura.ne.jp/m2/



On-Jin �`���l�`

http://on-jin.com/

�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q�Q

�yCHANGELOG�z

[Ver0.40 2017/10/09]
Implemented the English mode
Fixed behavior for drawing images

[Ver0.321 2016/12/25]

Fixed how the flag to buy from Voile's part-time girl was linked to the Usa Statue

Added 

DeadBody

 to the Number Trader: 

11111111





[Ver0.32 2016/12/25]

 �yMAIN GAME CHANGES�z

�EThe distribution of virus encounters has changed remarkably

�EThe busting rank at which viruses drop certain codes has changed.
�@Basically, high ranks tend to drop codes which are easy to use (such as A, M, S)

�EStunGame and BustrAmp are now sold at Voile

�EA part-time girl will now sell AddOns at Voile at the beginning of Chapter 4

�EThe contents of some random and blue mystery data have changed
�@(Excluding HPMemory and RegUp)

�EVarious shops have changed their wares. Why not take a peek?



 �ySYSTEM CHANGES�z

�EAdditional chip properties are now listed.
�@Except for objects, they become important with style changes.

�wBreak, Sword, Guard, Terrain Change, Status Infliction, Object�x

�EAfter any fight that gives you a specific style change for the first time, you'll receive an email
�@which discusses that style in-depth so you can read it at any time.

�EIf the folder rules aren't met, it'll be automatically set as a spare folder and colored red.



 �yPOISON ELEMENT BUFFS�z

�EPoison damage from WhiteLily and GasGarden PA does not affect poison element.
�@(BioSpray chips still work)

�EWhen poisoned and standing on poison panels,
�@healing effects will cause damage instead.



 �yADDON MANAGER�z

�EThe amount of Hertz and Cores given by some Minus AddOns has increased.



 �yCHANGES TO EXISTING CHIPS�z

�EHakkero (including Dark)

�@
Guards only for a brief moment when used


�ELifeShield

�@
Recover damage successfully blocked

�@�@�@�@�@�@�@�@��


�@Recover damage successfully blocked & reflect it



�ERelfectShield

�@
Reflect damage successfully blocked +100

�@�@�@�@�@�@�@�@��

�@Reflect double the damage successfully blocked



�EHakurouken
�@
Power was slightly decreased.



�ELance, KnightLance

�@Power was slightly increased.



�EChainGun

 MB decreased overall.
 ChainGun1 �� is now sold at the Central City Chip Shop.



�EDeathWiper

�@Power was slightly increased, and the higer-ranked chips' MB were decreased.



�ESandPit

�@Power was decreased, and in exchange the MB of SandPit3 was decreased.



�EShotGun

�@Power was increased by 10.



�EMonkeyPole

�@Power was slightly increased.



�ETripleRod

�@Break attribute was added.



�EWhiteLily, BlueLily

�@No longer required to be placed on grass.



�ERecov

�@The MB of some Recov chips were adjusted.


 �wNAVI CHIPS�x

�ESpannerMan

�@Overall power was increased, the shockwave is now 3 rows wide, and the knuckle stun duration was significantly increased.



�ETortoiseMan

�@Overall power was decreased.



�EPyroMan

�@Power was adjusted slightly.



 �wDARK CHIPS�x

�EDarkRayGun

�@Code changed from R to C

�@Changed the maximum damage from the Muramasa-like effect from 500 to HP-250



�EDarkWiper

�@Code changed from W to V
�@Power was slightly decreased, but opponent is now poisoned when hit



 �wPROGRAM ADVANCES�x

�EHiCannon, MegaHalberd
�@Power was increased.



�EKillerDoll

�@Power was increased.



�EGasGarden
�@A reminder that this does not damage poison elementals as noted above

��Newly added viruses are not shown in the waiting room



[Ver0.31 2016/04/13]

Fixed a bug where the style change menu didn't open when pressing up while on the OK button

Adjusted duration of Body chips

When selecting a style, pressing the R Button will show an explanation

When editing a folder, pressing START and SELECT will empty the folder

X chips can be put into chip traders

Fixed a bug where folders were messed up when saving after using a chip trader

Fixed some bugs dealing with skipping some parts of events



[Ver0.30 2016/04/10]

Adjusted how style changing in battle works

Added a command to start from the beginning in a special state



[Ver0.291 2016/03/09]

Fixed the behavior of Tomahawk

Fixed the behavior of MasterSpark



[Ver0.29 2016/03/08]

Fixed odd bugs with how the Tomahawk and TortoiseMan chips behave

Fixed the flight duration for VenomShot and BreakShot

Fixed other minor bugs



[Ver0.28 2016/03/05]

Fixed a freeze when using MasterSpark

Fixed a bug where MonkeyPole wouldn't work with stun

Fixed a bug where the game freezes when running from some viruses

Fixed a bug which messed up the request completion flags, and added measures to return the game to normal when a bug occurs

Fixed minor bugs



[Ver0.27 2016/03/02]

Fixed a bug where AxeHawkEX doesn't move

Adjusted the behavior of Sakuya and HakutakuMan chips

Fixed the behavior of PyroMan chip

Adjusted chip balance
Fixed a bug where nobody could move into a panel next to an enemy pulled by ElecChain

Added content for the Number Trader. One of them is 

25644364

 (it's a reference for you all)

Fixed minor bugs



[Ver0.261 2016/02/28]

Fixed a bug which prevented players from jacking in after Chapter 4



[Ver0.26 2016/02/28]

Fixed an odd bug with FlowerTank behavior

Fixed other minor bugs



[Ver0.251 2016/02/28]

Fixed a bug where enemy Navis would change shape during battle



[Ver0.25 2016/02/28]

Adjusted the rarity of Roukanken

Fixed an odd bug with request flags

Fixed a bug with odd drops from Paladin virus

Fixed a bug where a primary folder would become the spare folder

Fixed a bug where a request cube could be opened earlier than expected

Fixed a freeze when HakutakuMan enrages
Fixed a freeze when using WhiteCard

Fixed a freeze when TanuGod's statue is triggered

Adjusted the MB of rare chips

Fixed a bug where a hit could land during flashing invincibility

Changed the X chip art to match the appearance of SP Navis



[Ver0.24 2016/02/27]

Fixed the behavior of FlowerTank

Fixed a bug where Nekku's apartment could be entered earlier than expected

Adjusted the difficulty of Chapter 4's dungeon mechanics

Fixed minor typos and omitted characters



[Ver0.23 2016/02/27]

Added Chapter 4

Buffed the abilities of Ninja and Witch Styles

Fixed a bug where Chip Traders didn't save properly

Made other small adjustments



[Ver0.221 2015/09/17]

Fixed a freeze when using the Number Trader



[Ver0.22 2015/09/16]

Fixed a bug where 

!!

 appears when attacking an enemy on an ice panel, regardless of the attack's element

Fixed a freeze when purchasing HP Memory

Updated the artwork for Knife and Sword

Added 4 new chips

Added the Number Trader



[Ver0.21 2015/09/13]

Fixed some errors in the notation of some Program Advance recipes

Changed the name of some Program Advances
Fixed flaws in the map

Changed the contents of UnderNet 2 green mystery data
Added items to the store in Genso Area 2

Added items to the store in Eien Square
Fixed Gaia Style's charge shot so that it works on hole panels

Fixed a bug where the Chip Trader list didn't match the result

Changed game mechanics so that trying to buy a chip you can't carry will cancel the purchase

Fixed how bumping the character against the top of the map could cause the character to slip through

Fixed a bug where saving outside of the save screen could duplicate or delete chips

Changed game mechanics so that 

!!

 appears when damage is doubled by panel type or status condition



[Ver0.20 2015/08/14]

Remodeled the Wing Style graphics
Added some Program Advances

Added sword attribute
Fixed a bug where players could get stuck inside NPCs

Fixed numerical errors in various chips

Fixed bugs in some events



[Ver0.191 2015/08/12]

Fixed a bug where players could get stuck inside NPCs

Changed how caught viruses can be deposited (one-way)

Fixed numerical errors in various chips

Fixed bugs in some events



[Ver0.19 2015/08/10]

Added Chapter 3

Adjusted the abilities of Wing and Witch Styles



[Ver0.182 2015/01/25]

Fixed minor bugs

Added one Program Advance



[Ver0.181 2015/01/18]

Fixed a freeze involving the Chip Trader



[Ver0.18 2015/01/18]

Adjusted the chips given by the Chip Trader

Fixed a bug with Normal Navis sliding on ice panels

Corrected some text mistakes

Adjusted style requirements to make them easier to target



[Ver0.172 2015/01/15]

Fixed a freeze when using the Chip Trader

Fixed a bug where styles can only be poison element

Adjusted a few of the chip effects



[Ver0.17 2015/01/13]

Added the introduction to Chapter 3

Changed Shanghai's graphics

Changed the abilities of some bosses



[Ver0.16 2014/12/06]
Fixed a bug where fades to black would end invincibility

Fixed a bug in the behavior of RayCannonSP

Fixed a bug where Cirno's Ice Press would make holes

Fixed a bug with BibiBat HP

Fixed a freeze when selecting a blank slot in the folder editor

Fixed a bug where furniture would multiply

Changed the abilities of some chips

Changed the abilities of some bosses



[Ver0.15 2014/10/26]

Overhauled the abilities of some chips

Fixed small bugs with the map

Fixed a freeze when opening the Navi screen

Added one extra battle

Fixed a bug where the screen would be messed up after finishing the tutorial



[Ver0.14 2014/10/19]

Overhauled the purchase of Interiors. Their prices were decreased overall

Fixed a freeze when discarding the lowest Interior

Added mystery data to some cyberworlds

Adjusted the duration of SynchBody

Added an Interior shop to City Area 2

Fixed a bug where the music player wouldn't start

Adjusted the MB of some chips



[Ver0.13 2014/10/18]

Changed the title screen

Added Interiors

Overhauled the balance of some chips

Changed game mechanics so that stun is canceled when hit by an attack which causes invicibility

Partly changed extra bonuses

Fixed minor bugs

Added an option to the config: When window is inactive, BGM can be ON or OFF



[Ver0.12 2014/10/02]

Fixed how SakuyaV3 chip was named 

Sakuya



Fixed how attacks which hit invincible enemies are handled

Made minor adjustments to events

Fixed a bug where ChainGun targets Cubes pushed by enemies

Fixed a bug with how Normal Navis use BioSpray chip



[Ver0.11 2014/10/01]

Adjusted the difficulty of some parts

Added an event that indicates when Chapter 2 is completed

Fixed how the Chapter 2 boss's Navi chips had the same MB
Fixed discrepancies between messages and codes

Fixed a bug where the player cannot get out from between ice and Mama Shinki

Fixed a freeze when pushing sliding blocks

It's now possible to fight SakuyaV2 and V3

Fixed a bug where Lilies could be placed on top of each other

Fixed how face graphics weren't displayed at the end of Chapter 1

Fixed a bug where the player could be stuck on the client of Request #1

Fixed a bug where StunGame wouldn't apply to AuraSword

Fixed a bug where, in a battle with a Navi and a virus, defeating the Navi first would lock up the game

Fixed a bug where Knife had Break attribute
Fixed a bug in Chapter 2 where you could get stuck in punk NPCs

Fixed to allow SP viruses to be fought individually as a bonus

Added a limit to the number of AuraSword which can be bought
Adjusted the power of ChainGun



[Ver0.10 2014/09/28]

Fixed a bug where boss fights are skipped

Fixed how some events are forgotten

Fixed a bug where some events behave incorrectly

Fixed a bug where MarisaV3 became V2

Fixed a bug where Cubes pulled through the player would pass through the player

Fixed some typos in BBS messages



[Ver0.09 2014/09/28]

Fixed a bug where mystery data disappears when the menu is opened

Fixed circumstances where some objects are drawn in the wrong order

Fixed some school events to prevent players from going outside



[Ver0.08 2014/09/27]

Added Chapter 2

Adjusted game mechanics to allow A to be pressed and held while using chips while moving



[Ver0.07�@2014/06/28]

Adjusted the interval between encounters when using OpenPort

Fixed a bug concerning editing folders with 5 Navi chips
Fixed how the wrong BGM would play when jacking out of the Fire Hydrant Comp during an emergency

Fixed the collision detection around Mari's bed

Fixed the collision detection around the Plastic Model

Fixed a bug with the Regular System in the tutorial

Fixed how the number of frags was incorrectly displayed

Fixed a freeze when ColdAir hits at a specific timing

Fixed barrier transparency during full synchro

Fixed how sliding on ice panels wouldn't stop when sliding over a non-ice panel

Fixed how Sub Chip effect didn't reset when starting from the beginning

Fixed the size of doors' collision detection

Fixed a bug where hole panels would be closed during fades to black
Fixed the data list cursor drawing order

Added Subchip vendors to Genso Town

Changed some enemy encounters

Adjusted BubbleBlast firing speed



[Ver0.06�@2014/06/27]

Fixed a bug in the Navi chip number limit

Fixed a bug where an icicle appearing on a hole would appear in a strange place



[Ver0.05�@2014/06/26]

Fixed a bug where L Button hints would disappear after the Shanghai decompression event

Fixed Bombs to not explode over holes

Fixed a bug where the custom screen could open during fades to black
Fixed bugs with the Regular System
Fixed a bug with simultaneous push vectors

Fixed a bug where Sub Chips can be bought past the carrying capacity

Adjusted Sub Chip effect description

Fixed a bug where a mysterious chip named 

��

 could be selected

Adjusted charge shot mechanics



�mVer0.04�@2014/06/25�n

Fixed how some characters get stuck in the saving position

Fixed how V2 Navi chips didn't have a 100% drop rate
Fixed a bug with a PC Room desk

Fixed a bug where players could get stuck inside Navis in the Square

Added contents to green mystery data



�mVer0.03�@2014/06/24�n

Fixed a bug where a moving character is saved at its original position

Game version is now displayed on the title screen



�mVer0.02�@2014/06/23�n

Fixed typos

Fixed a bug where BGM would disappear after a V2 Navi fight

Fixed how some enemy combinations couldn't move

Fixed a bug where the player could become stuck between a boy and a tree
Added an event which was forgotten

Fixed the flag for Style Change



�mVer0.01�@2014/06/23�n

First public release, up to the end of Chapter 1

